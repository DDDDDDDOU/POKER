 import {createBottomTabNavigator} from "react-navigation-tabs";
import {LoginScreen} from "../screens/LoginScreen";
// import Ionicons from "react-native-vector-icons/Ionicons";
 import {createAppContainer} from "react-navigation";
// import React from "react";
import {HomeScreen} from "../screens/HomeScreen";
//
// const TabNavigator = createBottomTabNavigator(
//     {
//         Home:HomeScreen,
//         Login:LoginScreen
//     },
//     {
//         defaultNavigationOptions:({navigation,screenProps})=>({
//             tabBarIcon:({focused,horizontal,tintColor})=>{
//                 const {routeName} = navigation.state;
//                 let iconName;
//                 if(routeName=='Home'){
//                     iconName='ios-home'
//                 }else if(routeName=='Login'){
//                     iconName='ios-Login'
//                 }
//
//                 return <Ionicons name={iconName} size={25} color={tintColor} />;
//             },
//         }),
//         tabBarOptions:{
//             activeTintColor:"#409EFF",
//             inactiveTintColor:"#909399",
//         },
//
//
//
//
//     });
//
//
// const AppContainer= createAppContainer(BoNavigator);
// export function Home() {
//     return(<AppContainer/>);
// }



import React from 'react'


import Ionicons from 'react-native-vector-icons/Ionicons'
 import { createStackNavigator } from 'react-navigation-stack';

const BottomNavigator = createBottomTabNavigator(
    {
        Home: {
            screen: HomeScreen,
            navigationOptions: {
                title: "首页",
                tabBarIcon:({ focused, horizontal, tintColor })=>{
                    return <Ionicons name={'ios-home'} size={25} style={{color:tintColor}}/>
                }
            }
        },
        Login: {
            screen: LoginScreen,
            navigationOptions: {
                title: "登陆",
                tabBarIcon:({ focused, horizontal, tintColor })=>{
                    return <Ionicons name={'ios-heart'} size={25} style={{color:tintColor}}/>
                }
            }
        },

    },
    {
        tabBarOptions:{
            activeTintColor:"red"
        }
    }
)

const Appcontainer= createAppContainer(BottomNavigator)
export function Home() {
   return(
       <Appcontainer>

       </Appcontainer>
   );
}