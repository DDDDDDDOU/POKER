import React from 'react';
import {Text,View} from 'react-native';
export function SplashScreen() {
    return (
        <View>
            <Text>Loading...</Text>
        </View>
    );
}