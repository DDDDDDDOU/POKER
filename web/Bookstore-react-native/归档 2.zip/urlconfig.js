/**
 * Created by lpp on 2020/3/30.
 */
const apiUrl='http://192.168.0.102:8080';
export {apiUrl};