/**
 * Created by lpp on 2020/3/15.
 */
import React from 'react';
import {Text,View} from 'react-native';
export function SplashScreen() {
    return (
        <View>
            <Text>Loading...</Text>
        </View>
    );
}