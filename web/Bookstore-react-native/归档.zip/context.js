/**
 * Created by lpp on 2020/3/15.
 */
import React from "react";
const AuthContext = React.createContext();
export {AuthContext};