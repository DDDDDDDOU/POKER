package com.example.last;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LastApplicationTests {

    @Test
    void contextLoads() {
    }

}
