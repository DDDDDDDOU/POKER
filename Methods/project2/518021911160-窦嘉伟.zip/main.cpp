﻿#include <iostream>
#include "Dijkstra.h"

/**
 * You can use this file to test your code.
 */
int main()
{
    DijkstraProject2 pro;
    while(pro.readFromFile()){
    pro.run1();
    pro.run2();
    }
    

}
