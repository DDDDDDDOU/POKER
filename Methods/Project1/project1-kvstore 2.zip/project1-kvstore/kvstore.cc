#include "kvstore.h"
#include <string>
#include <iostream>
using namespace std;
KVStore::KVStore(const std::string &dir): KVStoreAPI(dir)
{
	srand(time(0));
	head = new node(0,"");
	tail = new node(UINT64_MAX,"");
	head->succ = tail;
	tail->pred = head;
	size = 0;
	 sst=new SStable;
	 //sst->Remove();

}



KVStore::~KVStore()
{
	reset();
	delete head;
	delete tail;

}

/**
 * Insert/Update the key-value pair.
 * No return values for simplicity.
 */
void KVStore::put(uint64_t key, const std::string &s)
{
	Put(key, s, head, tail);
	return;
}

/*
 * Returns the (string) value of the given key.
 * An empty string indicates not found.
 */
std::string KVStore::get(uint64_t key)
{
	node *del=head->succ;
	while(del!=nullptr){
		if(del->key==key&&del!=tail) {
		//	cout<<"in memt"<<endl;
			return del->value;
			}

		if(del->key>key) break;
		del=del->succ;
	}
	return sst->get(key);
	//return "";
}
/**
 * Delete the given key-value pair if it exists.
 * Returns false iff the key is not found.
 */
bool KVStore::del(uint64_t key)
{
	//memtable
	if(get(key)!="") {
		put(key,"");
		return true;
	}
	return false;
}

/**
 * This resets the kvstore. All key-value pairs should be removed,
 * including memtable and all sstables files.
 */
void KVStore::reset()
{
	//memtable
	clear();
	sst->Remove();
	//delete sst;
	//sst=new SStable;
//	sst->Remove();


	/*		 */	
	/*		 */
	/*sstable*/
	/*		 */
	/*		 */

	
	

}
void  KVStore::clear(){
	node *cur,*next;
	node *del;
	cur=head;
	while(cur->up!=nullptr) cur=cur->up;
	
	while (cur!=nullptr)
	{	next=cur;
		del=cur;
		while(next!=nullptr){
			del=next;
			next=next->succ;
			delete del;
		}
		cur=cur->down;

	}
	head = new node(0,"");
	tail = new node(UINT64_MAX,"");
	head->succ = tail;
	tail->pred = head;
	size=0;
}


void KVStore::display(){

	// node *tmp;
	// node *flg= head;

	// flg=head;
	// node *t=tail;
	// while(flg!=nullptr){
	// 	tmp = flg;
	// 	while(tmp!=t){

	// 		tmp = tmp->succ;
	// 	}
	// 	flg=flg->up;
	// 	t=t->up;
	// }
	sst->showlist();
return;
}

node* KVStore::Put(uint64_t key, const std::string &s, node *h, node *t){
	node *tmp = h;
	node *ta  = t;
	while(tmp->succ->key < key) tmp = tmp->succ;
	if(tmp->succ->key == key&&tmp->succ != t) {
		node *ex = tmp->succ;
		size+=(sizeof(char)*s.size()-sizeof(char)*ex->value.size());
		while(ex){
			ex->value = s;
			ex=ex->up;
		}
		if(size>(1<<21)-128) {
			sst->putFile(head,tail);
			clear();
			}
		return nullptr;
	}//换值
	node *flg = tmp->succ;
	tmp->succ = new node(key,s);
	flg->pred = tmp->succ;
	tmp->succ->succ = flg;
	tmp->succ->pred = tmp;//插入该层
	node *ne = tmp->succ;

	if(h->up == nullptr){
			h->up = new node(0,"");
			t->up = new node(UINT64_MAX,"");
			h->up->down = h;
			t->up->down = t;
			t->up->pred = h->up;
			h->up->succ = t->up;
		}
	if(rand()%2==0){
		//如果可以生长
		
		tmp=h->up;
		ta =t->up;
		node *u = Put(key,s,tmp,ta);
		ne->up = u;
		u->down= ne;

	}
	if(h==head){
		size+=(sizeof(uint64_t)*2+sizeof(char)*s.size())+sizeof(int);
		if(size>(1<<21)-128) {
			sst->putFile(head,tail);
			clear();
			return nullptr;
			}
		

	}
	 
	return ne;
}