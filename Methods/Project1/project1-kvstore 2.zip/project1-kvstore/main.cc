#include <iostream>
#include "kvstore.h"
using namespace std;
string re(int i){
		if(i==0) return "";
		if(i==1) {
			char *p = new char[1];
			p[0]='t';
			cout<<p<<endl;
			return p;
		}
	}
int main(){
    KVStore kv("./data");
    uint64_t i;

	for(i=0;i<1024*8;++i){
		kv.put (i,string(i,'s'));
	}
	for(i=0;i<1024*8;++i){
		kv.del (i);
	}
	for(i=0;i<1024*8;++i){
		kv.put (i,string(i,'t'));
	}
	for(i=0;i<1024*8;++i){
		kv.put (10240+i,string(i,'s'));
	}
	for(i=0;i<1024*8;++i){
		cout<<kv.get (i)[0]<<endl;
	}

    return 0 ;
}