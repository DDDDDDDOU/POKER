// #ifndef KVSTORE
// #define KVSTORE
#pragma once
#include <cstdlib>
#include <string>
using namespace std;
#include "kvstore_api.h"
#include "SStable.h"
#include "node.h"


class KVStore : public KVStoreAPI {
	// You can add your implementation here
private:
	SStable *sst;
	
	int size;
	node *head;
	node *tail;
public:
friend class SStable;
	KVStore(const std::string &dir);

	~KVStore();

	void put(uint64_t key, const std::string &s) override;
	
	node* Put(uint64_t key, const std::string &s, node *h,node *t);

	void display();
	void clear();

	void grow(node *t);

	std::string get(uint64_t key) override;

	bool del(uint64_t key) override;

	void reset() override;

	void transToSS();//转化为sstable

	void compact();//合并

};
//#endif