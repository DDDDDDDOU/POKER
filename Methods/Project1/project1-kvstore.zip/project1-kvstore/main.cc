#include <iostream>
#include "kvstore.h"
using namespace std;
int main(){
    KVStore kv("./data");
    // kv.put(UINT64_MAX,"123");//size=11
    // kv.put(123,"11");//size21
    // kv.put(1234555,"dads");   //33
    // kv.put(566,"123");//44
    // kv.put(566,"11");//43
 
    kv.put(0,"dsd");//54
    for(int i=1024*4;i>0;--i){
        kv.put(i,string(i,'a'));
        //cout<<kv.get(i);
       // cout<<"input"<<i<<endl;
    }
    for(int i=1024*4;i>0;--i){
        //kv.put(i,string(i,'a'));
        cout<<kv.get(i);
       // cout<<"input"<<i<<endl;
    }
    // kv.display();
    // kv.put(1,"12313");
    // kv.display();
    // kv.clear();
    // kv.display();
    // kv.put(1,"123");
    // kv.display();
    // cout<<kv.get(1);

    
    
   // kv.display();
  //  kv.display();
    return 0 ;
}