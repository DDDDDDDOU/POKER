#include "kvstore.h"
#include <string>
#include <iostream>
using namespace std;
KVStore::KVStore(const std::string &dir): KVStoreAPI(dir)
{
	srand(time(0));
	head = new node(0,"");
	tail = new node(UINT64_MAX,"");
	head->succ = tail;
	tail->pred = head;
	size = 0;
	 sst=new SStable;
	 sst->Remove();

}



KVStore::~KVStore()
{
	reset();
	delete head;
	delete tail;

}

/**
 * Insert/Update the key-value pair.
 * No return values for simplicity.
 */
void KVStore::put(uint64_t key, const std::string &s)
{
	cout<<"put"<<endl;
	Put(key, s, head, tail);
	cout<<"has put"<<key<<'\t'<<s<<endl;
	return;
}

/*
 * Returns the (string) value of the given key.
 * An empty string indicates not found.
 */
std::string KVStore::get(uint64_t key)
{
	//memtable
//	int i;
	cout<<"toget:"<<key<<endl;
		//if(size<3000) cin>>i;;
	node *del=head->succ;
	while(del!=nullptr){
		if(del->key==key&&del!=tail) return del->value;
		if(del->key>key) return sst->get(key);
		del=del->succ;
	}
	return sst->get(key);
	//return "";
}
/**
 * Delete the given key-value pair if it exists.
 * Returns false iff the key is not found.
 */
bool KVStore::del(uint64_t key)
{
	cout<<"start delete"<<endl;
	//memtable
	if(get(key)!="") {
		put(key,"");
		return true;
	}
	return false;
}

/**
 * This resets the kvstore. All key-value pairs should be removed,
 * including memtable and all sstables files.
 */
void KVStore::reset()
{
	//memtable
	cout<<"reset!"<<endl;
	clear();
	sst->Remove();
	//sst->Remove();
	// delete sst;
	// sst=new SStable;

	/*		 */	
	/*		 */
	/*sstable*/
	/*		 */
	/*		 */

	
	

}
void  KVStore::clear(){
	node *cur,*next;
	node *del;
	cur=head;
	while(cur->up!=nullptr) cur=cur->up;
	
	while (cur!=nullptr)
	{	next=cur;
		del=cur;
		while(next!=nullptr){
			del=next;
			next=next->succ;
			delete del;
		}
		cur=cur->down;

	}
	head = new node(0,"");
	tail = new node(UINT64_MAX,"");
	head->succ = tail;
	tail->pred = head;
	size=0;
}


void KVStore::display(){

	node *tmp;
	node *flg= head;
	// while(flg){
	// 	cout<<flg->key<<endl;
	// 	flg=flg->up;
	// }
	flg=head;
	node *t=tail;
	while(flg!=nullptr){
		tmp = flg;
		while(tmp!=t){
			//cout<<"succ"<<endl;
			cout<<tmp->key<<":"<<tmp->value<<'\t';
			tmp = tmp->succ;
		}
		cout<<endl;
		flg=flg->up;
		t=t->up;
	}
return;
}

node* KVStore::Put(uint64_t key, const std::string &s, node *h, node *t){
	node *tmp = h;
	node *ta  = t;
	while(tmp->succ->key < key) tmp = tmp->succ;
//	cout<<"aaa"<<endl;
	if(tmp->succ->key == key&&tmp->succ != t) {
		node *ex = tmp->succ;
		size+=(sizeof(char)*s.size()-sizeof(char)*ex->value.size());
		while(ex){
			ex->value = s;
			ex=ex->up;
		}
		cout<<size<<endl;
		return tmp->succ;
	}//换值
	node *flg = tmp->succ;
	tmp->succ = new node(key,s);
	flg->pred = tmp->succ;
	tmp->succ->succ = flg;
	tmp->succ->pred = tmp;//插入该层
	node *ne = tmp->succ;
	//  cout<<"ne->succ:"<<ne->succ->key<<endl; 
	//  cout<<"h->succ :"<<h->succ->key<<endl;
	if(h->up == nullptr){
			h->up = new node(0,"");
		//	cout<<h->up->key<<"\t";
			t->up = new node(UINT64_MAX,"");
			h->up->down = h;
			t->up->down = t;
			t->up->pred = h->up;
			h->up->succ = t->up;
		}
	if(rand()%2==0){
		//如果可以生长
		//cout<<"key grow: "<<key<<endl;
		
		tmp=h->up;
		ta =t->up;
		node *u = Put(key,s,tmp,ta);
		ne->up = u;
		u->down= ne;
		//cout<<"u->succ:"<<u->succ->key<<endl;

	}
	if(h==head){
		size+=(sizeof(uint64_t)*2+sizeof(char)*s.size())+sizeof(int);
		if(size>(1<<21)-128) {
			cout<<"PUT!"<<endl;
			sst->putFile(head,tail);
			cout<<"return to kvstore"<<endl;
			clear();
			display();
			cout<<"has clear"<<head->succ->key<<endl;
			return nullptr;
			}
		
//	cout<<sizeof(uint64_t)<<'\t'<<sizeof(char)<<'\t'<<s.size()<<endl;
 //	cout<<size<<endl; 
	}
	 
	return ne;
}